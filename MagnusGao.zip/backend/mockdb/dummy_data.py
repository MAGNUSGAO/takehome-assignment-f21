initial_db_state = {
    "shows": [
        {"id": 1, "name": "Game of Thrones", "episodes_seen": 0},
        {"id": 2, "name": "Naruto", "episodes_seen": 220},
        {"id": 3, "name": "Black Mirror", "episodes_seen": 3},
    ]
}
